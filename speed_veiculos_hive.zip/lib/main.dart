
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';

void main() async {
  await Hive.initFlutter();
  Hive.registerAdapter(VeiculoAdapter());
  Hive.registerAdapter(GastoAdapter());
  await Hive.openBox<Veiculo>('veiculosBox');
  runApp(const SpeedVeiculosApp());
}

class SpeedVeiculosApp extends StatelessWidget {
  const SpeedVeiculosApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Speed Veículos',
      theme: ThemeData(
        primaryColor: Colors.red,
        scaffoldBackgroundColor: Colors.black,
        colorScheme: ColorScheme.fromSwatch().copyWith(secondary: Colors.red),
        textTheme: const TextTheme(bodyMedium: TextStyle(color: Colors.white)),
      ),
      home: const VeiculosPage(),
    );
  }
}

// Model Hive
@HiveType(typeId: 0)
class Veiculo extends HiveObject {
  @HiveField(0)
  String moto;
  @HiveField(1)
  int ano;
  @HiveField(2)
  DateTime dataCompra;
  @HiveField(3)
  double valorCompra;
  @HiveField(4)
  double custoTotal;
  @HiveField(5)
  DateTime? dataVenda;
  @HiveField(6)
  double? valorVenda;
  @HiveField(7)
  double? comissao;
  @HiveField(8)
  double? lucro;
  @HiveField(9)
  String? observacao;
  @HiveField(10)
  List<Gasto> gastos;

  Veiculo({
    required this.moto,
    required this.ano,
    required this.dataCompra,
    required this.valorCompra,
    required this.custoTotal,
    this.dataVenda,
    this.valorVenda,
    this.comissao,
    this.lucro,
    this.observacao,
    required this.gastos,
  });

  void calcularCustos() {
    double totalGastos = gastos.fold(0, (sum, g) => sum + g.valor);
    custoTotal = valorCompra + totalGastos;
    if (valorVenda != null) {
      lucro = valorVenda! - custoTotal;
      comissao = lucro! * 0.1;
    }
  }
}

@HiveType(typeId: 1)
class Gasto {
  @HiveField(0)
  String descricao;
  @HiveField(1)
  double valor;
  @HiveField(2)
  DateTime data;

  Gasto({required this.descricao, required this.valor, required this.data});
}

// O restante do código permanece semelhante, mas usando Box para salvar e recuperar dados
// ... (Adaptação das páginas VeiculosPage, AddVeiculoPage e DetalhesVeiculoPage usando Hive)
